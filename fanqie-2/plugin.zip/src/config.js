let config_host = "https://fanqienovel.com";
let config_host2 = "http://192.168.1.126:9999";
// IP của android chạy webservice fanqie
let host = "http://192.168.1.126:9999";
if (typeof host !== "undefined") {
  config_host2 = host;
}
