async function test() {
  const verifyCode = await getVerifyCode();

  const URL_CHAPTER =
    "https://api.softrr.cn/api/fanqie/?id=7173217408294453791&code=" +
    verifyCode;

  const response = await fetch(URL_CHAPTER);
  if (response.ok) {
    const json = await response.json();
    const htmlContent = json.data;
    console.log(extractChapterContent(htmlContent));
  }
}

test();

function extractChapterContent(htmlString) {
  const articleStart = htmlString.indexOf("<article>");
  const articleEnd = htmlString.indexOf("</article>");
  const articleContent = htmlString.substring(articleStart + 9, articleEnd);
  console.log("CHECK:: \n", articleContent);
  let result = articleContent
    .replace(/<p[^>]*>/g, "")
    .replace(/<\/p>/g, "\n")
    .trim();

  return result;
}

async function getVerifyCode() {
  const VERIFY_URL = "https://api.softrr.cn/api/verification/?id=1";
  const response = await fetch(VERIFY_URL);
  if (response.ok) {
    const json = await response.json();
    const code = json.code;
    return code;
  }
}
